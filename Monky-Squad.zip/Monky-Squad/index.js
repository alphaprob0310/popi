const { Interaction } = require('discord.js');
const Discord = require('discord.js');
const { Token, Prefix, SalonIDArriver, SalonIDDépart, GardeIDcommunauté, Alpha_ProbeID, SalonIDTicket, SalonIDTicketArchive} = require("./data.json");
const client  = new Discord.Client({ intents: 515 });

client.on('ready', async () =>{
    
    console.log("========================");
    console.log("jean_bot_monk is Started");
    console.log("========================");

    /*const row = new Discord.MessageActionRow()
        .addComponents(new Discord.MessageButton()
            .setCustomId("open-ticket")
            .setLabel("ouvrir un ticket")
            .setStyle("PRIMARY")
        );

    client.channels.cache.get("1002256917546139779").send({content: "Appuyez sur le bouton pour ouvrir un ticket", components:[row]});*/

    client.user.setStatus("dnd");
    const statuses = [
        () => `Communauté de Alpha_Probe`,
        () => `/help`
    ]

    let i = 0;
    setInterval( () =>{
        client.user.setActivity(statuses[i](), {type: 'WATCHING'})
        i = ++i % statuses.length
    }, 5000);
    
    setInterval(() =>{
        console.log("Is online");
    }, 5000);
});

client.on('messageCreate', message =>{
    if(message.author.bot) return;

    const args = message.content
    .toLowerCase()
    .slice(Prefix.length)
    .trim()
    .split(/\s+/);
    const [command, input] = args;

    if(message.content == Prefix + "ping"){
        message.reply({content: ' 🏓 pong !', ephemeral: true});
        const ping = client.ws.ping;
        if(ping <= 100){
            color = ":green_square:";
        }else if(ping > 100){
            color = ":red_square:";
        }
        message.channel.send("Mon ping et de " + ping + " ms! \n" + color);
        //message.delete();
    }

    if(message.content == Prefix + "help" ){
        const embed = new Discord.MessageEmbed()
            .setColor("#4af308")
            .setTitle("**Les commandes de ce bot sont : **")
            .setAuthor("Alpha_Probe#7865", "https://cdn.discordapp.com/avatars/902626356414775356/80fd22449f6615f7e25fab6314660420.webp?size=128", "https://discord.js.org/")
            .setDescription("----------------------------------------")
            .setThumbnail("https://cdn.discordapp.com/avatars/902626356414775356/80fd22449f6615f7e25fab6314660420.webp?size=128")
            .addField("__/help__", "Affiche la liste des commandes dispoibles")
            .addField("__/ping__", "Te retourne ton ping actuel")
            .addField("__/reseau__", "Afficher le reseau de Albinos")
            .addField("__/clear + nombre__", "Supprime les message (MANAGE_MESSAGES) compris enre 1 et 99")
            .addField("__/stop__", "Permet d'arreter le bot (seul le fondateur peux le faire)")
            .setFooter("Ce bot appartient à Alpha_Probe", "https://cdn.discordapp.com/avatars/902626356414775356/80fd22449f6615f7e25fab6314660420.webp?size=128")
            .setTimestamp();

        message.channel.send( {embeds: [embed]});
    }

    if (command == 'clear') {
        if (!message.member.permissions.has('MANAGE_MESSAGES')) {
        return message.channel
            .send(
            "Vous ne pouvez pas utiliser cette commande car il vous manque 'manage_messages' perm",
            );
        }

        if (isNaN(input)) {
        return message.channel
            .send('entrez le nombre de messages que vous souhaitez effacer')
            .then((sent) => {
            setTimeout(() => {
                sent.delete();
            }, 2500);
            });
        }

        if (Number(input) < 0) {
        return message.channel
            .send('Enter un chiffre positif')
            .then((sent) => {
            setTimeout(() => {
                sent.delete();
            }, 2500);
            });
        } 
        else if(Number(input) > 99){
            return message.channel
            .send('Vous ne pouvez pas éffacer plus de 99 messages a la fois')
            .then((sent) => {
            setTimeout(() => {
                sent.delete();
            }, 2500);
            });
        }

        const amount = Number(input) > 100
        ? 101
        : Number(input) + 1;

        message.channel.bulkDelete(amount, true)
        .then((_message) => {
        message.channel
            .send(`Le bot a éffacé \`${_message.size}\` messages :broom:`)
            .then((sent) => {
            setTimeout(() => {
                sent.delete();
            }, 2500);
            });
        });
    }

    if (message.content == Prefix + 'regle') {
        if (!message.member.permissions.has('MANAGE_MESSAGES')) {
            return message.channel
                .send(
                "Vous ne pouvez pas utiliser cette commande car il vous manque 'manage_messages' perm",
                );
            }

        const embed = new Discord.MessageEmbed()
            .setColor("#4af308")
            .setTitle("**Les regles de notre serveur sont: **")
            .setAuthor("Alpha_Probe#7865", "https://cdn.discordapp.com/avatars/902626356414775356/80fd22449f6615f7e25fab6314660420.webp?size=128", "https://discord.js.org/")
            .setDescription("Ce discord est un endroit neutre : les propos racistes, homophobes, sexistes et/ou religieux sont interdit.\n• Les liens renvoyant vers de sites frauduleux, à caractère pornographiques, illégaux ou de piratage sont interdits.\n• Il est interdit de spam/flood, que ce soit en termes d’image(s) et/ou de texte(s).\n• Tout contournement d’un Mute ou d’un Bannissement (par la réinscription sous un autre compte par exemple) sera sanctionné sans délais.\n• Toute forme de publicité est interdite.\n• Les spoilers ne sont pas autorisés.\n• L’annonce de vente et revente est interdite sur le serveur. Néanmoins vous pouvez aborder le sujet et continuer en messagerie privée, cela n’engageant que votre responsabilité propre. Aucun membre du Staff SGC n’est responsable. Le Discord n’étant pas dédié à cette fin.\n• La demande d’informations personnelles de quelque nature que ce soit (ceci inclus notamment les informations de compte) sont interdites..\nSeuls les messages d’ordre général et plus particulièrement sur le gaming y sont autorisés dans les différent salons du serveur Discord SGC." )
            .setThumbnail("https://cdn.discordapp.com/avatars/902626356414775356/80fd22449f6615f7e25fab6314660420.webp?size=128")
            .setFooter("Ce bot appartient à Alpha_Probe", "https://cdn.discordapp.com/avatars/902626356414775356/80fd22449f6615f7e25fab6314660420.webp?size=128")
            .setTimestamp();

    message.channel.send( {embeds: [embed]});
    }       

    if(message.content == Prefix + "stop"){
        if(message.member.id == Alpha_ProbeID){
            message.channel.send("Vous venez d'arréter le bot")
            client.destroy();
        }else{
            message.reply({ content: "Seul le fondateur du serveur peux éxécuter c'ette commande"});
        }
    }

    if(message.content == Prefix + "reseau"){

        const row = new Discord.MessageActionRow()
            .addComponents(new Discord.MessageButton()
                .setLabel("Mon Instagrame")
                .setURL("https://www.instagram.com/w_e_t_y/")
                .setStyle("LINK")
                .setEmoji("👍")
            );
        message.channel.send({ content: "si tu n'est pas abonnée a Albinos", components: [row]});
    }

});

client.on("interactionCreate", interaction =>{
    if(interaction.isButton()){
        if(interaction.customId == "open-ticket"){
            interaction.guild.channels.create("ticket-" + interaction.user.id , {
                parent: SalonIDTicket,
                permissionOverwrites: [
                    {
                        id: interaction.guild.id,
                        deny: [Discord.Permissions.FLAGS.VIEW_CHANNEL]
                    },
                    {
                        id: interaction.user.id,
                        allow: [Discord.Permissions.FLAGS.VIEW_CHANNEL]
                    }
                ]
            }).then( channel =>{
                const row = new Discord.MessageActionRow()
                    .addComponents(new Discord.MessageButton()
                        .setCustomId("close-ticket")
                        .setLabel("fermet le ticket")
                        .setStyle("DANGER")
                    );
                channel.send({content: "<@" + interaction.user.id + "> Voici votre ticket, vous pouvez le fermet en appuiant sur le bouton", components: [row]});
                interaction.reply({content: "Votre ticket a bien était créée", ephemeral: true})
            });
        }
        else if(interaction.customId == "close-ticket"){
            interaction.channel.setParent(SalonIDTicketArchive);

            const row = new Discord.MessageActionRow()
                .addComponents(new Discord.MessageButton()
                    .setCustomId("delete-ticket")
                    .setLabel("supprimer le ticket")
                    .setStyle("DANGER")
                );

                interaction.channel.delete();
        }
        else if(interaction.customId == "delete-ticket"){
            interaction.channel.delete();
        }
    }
});

client.on('guildMemberAdd', member =>{

    const user = client.users.fetch(member.id);

    const embed = new Discord.MessageEmbed()
        .setTitle(`Bienvenue sur Monkey Squad !`)
        .setColor(0xff0000)
        .setDescription(`${member}, toute l'équipe de Monkey Squad et sa communauté te souhaite la bienvenue !`)
        .setURL('https://www.minefight.fr')
        .setFooter(`N'oubliez pas de respecter les règles du serveur Discord.`)
        .setThumbnail(user.displayName);

    client.channels.cache.get(SalonIDArriver).send({embeds: [embed]});
    member.roles.add(GardeIDcommunauté);
});

client.on('guildMemberRemove', member =>{
    console.log("snif! un membre vient de nous quitter");
    const user = client.users.fetch(member.id);

    const embed = new Discord.MessageEmbed()
        .setTitle(`Au revoir sur Monkey Squad !`)
        .setColor(0xff0000)
        .setDescription(`${member}, toute l'équipe de Monkey Squad et sa communauté est triste de te voir partir !`)
        .setThumbnail(user.displayName);

    client.channels.cache.get(SalonIDDépart).send({embeds: [embed]});
});

client.login(process.env.Token);
